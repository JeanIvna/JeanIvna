import { useParams, Link } from "wouter";
import { ArrowLeft, Clock, Users, Star, Download, Play, BookOpen } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CyberButton } from "@/components/ui/cyber-button";
import { useFormation } from "@/hooks/use-formations";
import { FORMATION_LEVELS, FORMATION_CATEGORIES, TELEGRAM_CHANNEL_URL } from "@/lib/constants";
import { Skeleton } from "@/components/ui/skeleton";

export default function FormationDetail() {
  const { id } = useParams();
  const { data: formation, isLoading, error } = useFormation(parseInt(id || "0"));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-cyber-dark">
        <div className="container mx-auto px-6 py-12">
          <Skeleton className="h-8 w-32 mb-8 bg-cyber-secondary" />
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="h-64 w-full bg-cyber-secondary" />
              <Skeleton className="h-8 w-3/4 bg-cyber-secondary" />
              <Skeleton className="h-32 w-full bg-cyber-secondary" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-48 w-full bg-cyber-secondary" />
              <Skeleton className="h-32 w-full bg-cyber-secondary" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !formation) {
    return (
      <div className="min-h-screen bg-cyber-dark flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Formation introuvable</h2>
          <p className="text-cyber-text-secondary mb-6">
            La formation que vous recherchez n'existe pas ou a été supprimée.
          </p>
          <Link href="/formations">
            <CyberButton variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour aux formations
            </CyberButton>
          </Link>
        </div>
      </div>
    );
  }

  const levelInfo = FORMATION_LEVELS[formation.level as keyof typeof FORMATION_LEVELS];
  const categoryInfo = FORMATION_CATEGORIES[formation.category as keyof typeof FORMATION_CATEGORIES];

  return (
    <div className="min-h-screen bg-cyber-dark">
      <div className="container mx-auto px-6 py-12">
        {/* Breadcrumb */}
        <Link href="/formations">
          <div className="flex items-center text-cyber-accent hover:text-cyan-400 transition-colors duration-300 mb-8 cursor-pointer">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour aux formations
          </div>
        </Link>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Formation Image */}
            {formation.imageUrl && (
              <div className="relative overflow-hidden rounded-xl mb-8">
                <img 
                  src={formation.imageUrl} 
                  alt={formation.title}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark/80 to-transparent"></div>
                <div className="absolute bottom-4 left-4">
                  <div className="flex items-center space-x-3">
                    <Badge className={levelInfo?.color || "bg-cyber-accent/20 text-cyber-accent"}>
                      {levelInfo?.label || formation.level}
                    </Badge>
                    <Badge variant="outline" className="border-white text-white">
                      {categoryInfo?.label || formation.category}
                    </Badge>
                  </div>
                </div>
              </div>
            )}

            {/* Formation Header */}
            <div className="mb-8">
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
                {formation.title}
              </h1>
              
              <p className="text-xl text-cyber-text-secondary leading-relaxed mb-6">
                {formation.description}
              </p>

              <div className="flex items-center space-x-6 text-cyber-text-secondary">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5" />
                  <span>{formation.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5" />
                  <span>1.2k étudiants</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-yellow-400" />
                  <span>4.8/5</span>
                </div>
              </div>
            </div>

            {/* Formation Content */}
            <Card className="bg-cyber-secondary border-border mb-8">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Contenu de la formation</h2>
                <div className="prose prose-invert max-w-none">
                  <p className="text-cyber-text-secondary leading-relaxed">
                    {formation.content}
                  </p>
                  
                  <div className="mt-8 p-6 bg-cyber-dark rounded-lg">
                    <h3 className="text-lg font-semibold text-cyber-accent mb-4">
                      🎯 Ce que vous allez apprendre
                    </h3>
                    <ul className="space-y-2 text-cyber-text-secondary">
                      <li>✅ Les concepts fondamentaux de la sécurité informatique</li>
                      <li>✅ Les outils et techniques utilisés par les professionnels</li>
                      <li>✅ Les bonnes pratiques de sécurité à appliquer</li>
                      <li>✅ Des exercices pratiques pour consolider vos connaissances</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Media Content */}
            <div className="grid md:grid-cols-2 gap-6">
              {formation.videoUrl && (
                <Card className="bg-cyber-secondary border-border">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-cyber-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Play className="w-8 h-8 text-cyber-accent" />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Vidéo du cours</h3>
                    <p className="text-cyber-text-secondary text-sm mb-4">
                      Accédez au contenu vidéo complet
                    </p>
                    <CyberButton size="sm" className="w-full">
                      Regarder la vidéo
                    </CyberButton>
                  </CardContent>
                </Card>
              )}

              {formation.downloadUrl && (
                <Card className="bg-cyber-secondary border-border">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-cyber-blue/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Download className="w-8 h-8 text-cyber-blue" />
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">Ressources PDF</h3>
                    <p className="text-cyber-text-secondary text-sm mb-4">
                      Téléchargez les supports de cours
                    </p>
                    <CyberButton variant="outline" size="sm" className="w-full">
                      Télécharger PDF
                    </CyberButton>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Info */}
            <Card className="bg-cyber-secondary border-border">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Informations</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-cyber-text-secondary">Niveau</span>
                    <Badge className={levelInfo?.color || "bg-cyber-accent/20 text-cyber-accent"}>
                      {levelInfo?.label || formation.level}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-cyber-text-secondary">Durée</span>
                    <span className="text-white">{formation.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-cyber-text-secondary">Catégorie</span>
                    <span className="text-white">{categoryInfo?.label || formation.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-cyber-text-secondary">Prix</span>
                    <span className="text-cyber-accent font-semibold">Gratuit</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Join Community CTA */}
            <Card className="bg-gradient-to-br from-cyber-accent to-cyber-blue border-0">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                  </svg>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Rejoignez la communauté</h3>
                <p className="text-white/80 text-sm mb-4">
                  Discutez de cette formation avec d'autres étudiants
                </p>
                <CyberButton
                  variant="default"
                  size="sm"
                  className="w-full bg-white text-cyber-dark hover:bg-gray-100"
                  onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                >
                  Rejoindre Telegram
                </CyberButton>
              </CardContent>
            </Card>

            {/* Additional Resources */}
            <Card className="bg-cyber-secondary border-border">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Ressources complémentaires</h3>
                <ul className="space-y-3">
                  <li>
                    <a href="#" className="flex items-center space-x-3 text-cyber-text-secondary hover:text-cyber-accent transition-colors">
                      <BookOpen className="w-4 h-4" />
                      <span>Documentation officielle</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center space-x-3 text-cyber-text-secondary hover:text-cyber-accent transition-colors">
                      <BookOpen className="w-4 h-4" />
                      <span>Exercices pratiques</span>
                    </a>
                  </li>
                  <li>
                    <a href="#" className="flex items-center space-x-3 text-cyber-text-secondary hover:text-cyber-accent transition-colors">
                      <BookOpen className="w-4 h-4" />
                      <span>Outils recommandés</span>
                    </a>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
