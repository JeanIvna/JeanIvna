import { useState } from "react";
import { NewsCard } from "@/components/news/news-card";
import { useArticles } from "@/hooks/use-news";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { ARTICLE_CATEGORIES } from "@/lib/constants";
import { Skeleton } from "@/components/ui/skeleton";

export default function Actualites() {
  const [filters, setFilters] = useState<{ category?: string; search?: string }>({});
  const { data: articles, isLoading, error } = useArticles(filters);

  const handleCategoryFilter = (category: string) => {
    const newCategory = filters.category === category ? undefined : category;
    setFilters({ ...filters, category: newCategory });
  };

  const handleSearchChange = (search: string) => {
    setFilters({ ...filters, search });
  };

  if (error) {
    return (
      <div className="min-h-screen bg-cyber-dark flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Erreur de chargement</h2>
          <p className="text-cyber-text-secondary">Impossible de charger les actualités.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cyber-dark">
      {/* Header */}
      <section className="py-20 bg-gradient-to-b from-cyber-dark to-cyber-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Actualités <span className="text-cyber-accent">Cybersécurité</span>
            </h1>
            <p className="text-xl text-cyber-text-secondary max-w-3xl mx-auto">
              Restez informé des dernières menaces, failles de sécurité et innovations dans le domaine de la cybersécurité.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="space-y-6">
            {/* Search Bar */}
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyber-text-secondary" />
              <Input
                type="text"
                placeholder="Rechercher des actualités..."
                value={filters.search || ""}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="pl-10 bg-cyber-dark border-border focus:border-cyber-accent"
              />
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap justify-center gap-3">
              <Button
                variant={!filters.category ? "default" : "outline"}
                onClick={() => setFilters({})}
                className={
                  !filters.category
                    ? "bg-cyber-accent text-cyber-dark hover:bg-cyan-400"
                    : "border-border text-cyber-text hover:bg-cyber-secondary"
                }
              >
                Toutes
              </Button>

              {Object.entries(ARTICLE_CATEGORIES).map(([category, info]) => (
                <Button
                  key={category}
                  variant={filters.category === category ? "default" : "outline"}
                  onClick={() => handleCategoryFilter(category)}
                  className={
                    filters.category === category
                      ? "bg-cyber-accent text-cyber-dark hover:bg-cyan-400"
                      : "border-border text-cyber-text hover:bg-cyber-secondary"
                  }
                >
                  {info.label}
                </Button>
              ))}
            </div>

            {/* Active Filters Display */}
            {(filters.category || filters.search) && (
              <div className="flex items-center justify-center gap-2 text-sm text-cyber-text-secondary">
                <span>Filtres actifs:</span>
                {filters.category && (
                  <span className="px-2 py-1 bg-cyber-accent/20 text-cyber-accent rounded">
                    Catégorie: {ARTICLE_CATEGORIES[filters.category as keyof typeof ARTICLE_CATEGORIES]?.label}
                  </span>
                )}
                {filters.search && (
                  <span className="px-2 py-1 bg-cyber-secondary border border-border rounded">
                    Recherche: "{filters.search}"
                  </span>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFilters({})}
                  className="text-cyber-accent hover:text-cyan-400"
                >
                  Effacer
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-12 bg-cyber-dark">
        <div className="container mx-auto px-6">
          {isLoading ? (
            <div className="space-y-8">
              {/* Featured Article Skeleton */}
              <div className="animate-pulse">
                <Skeleton className="h-64 w-full bg-cyber-secondary rounded-xl" />
              </div>
              
              {/* Regular Articles Skeleton */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="h-48 w-full bg-cyber-secondary rounded-lg" />
                    <Skeleton className="h-4 w-3/4 bg-cyber-secondary" />
                    <Skeleton className="h-4 w-1/2 bg-cyber-secondary" />
                    <Skeleton className="h-16 w-full bg-cyber-secondary" />
                  </div>
                ))}
              </div>
            </div>
          ) : articles && articles.length > 0 ? (
            <div className="space-y-8">
              {/* Featured Article */}
              {articles[0] && (
                <NewsCard article={articles[0]} featured />
              )}
              
              {/* Regular Articles Grid */}
              {articles.length > 1 && (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {articles.slice(1).map((article) => (
                    <NewsCard key={article.id} article={article} />
                  ))}
                </div>
              )}
              
              {/* Results Count */}
              <div className="text-center mt-12">
                <p className="text-cyber-text-secondary">
                  Affichage de {articles.length} article{articles.length > 1 ? 's' : ''}
                  {filters.category && ` dans la catégorie "${ARTICLE_CATEGORIES[filters.category as keyof typeof ARTICLE_CATEGORIES]?.label}"`}
                  {filters.search && ` pour la recherche "${filters.search}"`}
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-20">
              <div className="max-w-md mx-auto">
                <div className="w-24 h-24 bg-cyber-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-12 h-12 text-cyber-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-cyber-text mb-2">Aucun article trouvé</h3>
                <p className="text-cyber-text-secondary mb-6">
                  Aucun article ne correspond à vos critères de recherche. Essayez de modifier vos filtres.
                </p>
                <button
                  onClick={() => setFilters({})}
                  className="text-cyber-accent hover:text-cyan-400 transition-colors duration-300"
                >
                  Effacer tous les filtres
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
