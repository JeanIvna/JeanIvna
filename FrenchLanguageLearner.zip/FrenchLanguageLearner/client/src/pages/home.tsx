import { Link } from "wouter";
import { GraduationCap, Users, Shield, BookOpen, ArrowRight, Zap, Globe, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { CyberButton } from "@/components/ui/cyber-button";
import { FormationCard } from "@/components/formations/formation-card";
import { NewsCard } from "@/components/news/news-card";
import { usePopularFormations } from "@/hooks/use-formations";
import { useFeaturedArticles } from "@/hooks/use-news";
import { TELEGRAM_CHANNEL_URL, SITE_STATS } from "@/lib/constants";

export default function Home() {
  const { data: popularFormations, isLoading: loadingFormations } = usePopularFormations();
  const { data: featuredArticles, isLoading: loadingArticles } = useFeaturedArticles();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden cyber-gradient">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 border border-cyber-accent rounded-full"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 border border-cyber-blue rounded-full"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-128 h-128 border border-cyber-accent/50 rounded-full"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            {/* Floating badge */}
            <div className="animate-float mb-8">
              <div className="inline-flex items-center glass-effect rounded-full px-6 py-3 border border-cyber-accent/30">
                <span className="text-cyber-accent text-sm font-medium">🔐 Formations • Outils • Actualités</span>
              </div>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-cyber-accent via-white to-cyber-accent bg-clip-text text-transparent">
              Maîtrisez la<br />
              <span className="text-cyber-accent">Cybersécurité</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-cyber-text-secondary mb-8 leading-relaxed">
              Formations gratuites, outils pratiques et actualités sur la sécurité informatique. 
              Rejoignez notre <span className="text-cyber-accent font-semibold">{SITE_STATS.members}</span> en cybersécurité.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <CyberButton
                variant="telegram"
                size="lg"
                glow
                onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                className="flex items-center space-x-3"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                </svg>
                <span>Rejoindre le Canal Telegram</span>
              </CyberButton>
              
              <Link href="/formations">
                <CyberButton
                  variant="outline"
                  size="lg"
                  className="flex items-center space-x-2"
                >
                  <BookOpen className="w-5 h-5" />
                  <span>Explorer les Formations</span>
                </CyberButton>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-cyber-accent">{SITE_STATS.tutorials}</div>
                <div className="text-sm text-cyber-text-secondary">Tutoriels</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-cyber-accent">{SITE_STATS.tools}</div>
                <div className="text-sm text-cyber-text-secondary">Outils</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-cyber-accent">Nouveau</div>
                <div className="text-sm text-cyber-text-secondary">Projet</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-cyber-accent">100%</div>
                <div className="text-sm text-cyber-text-secondary">Gratuit</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Formations Section */}
      <section className="py-20 bg-gradient-to-b from-cyber-dark to-cyber-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-white">
              Formations <span className="text-cyber-accent">Populaires</span>
            </h2>
            <p className="text-xl text-cyber-text-secondary max-w-3xl mx-auto">
              Découvrez nos formations les plus appréciées par la communauté.
            </p>
          </div>

          {loadingFormations ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-cyber-secondary rounded-xl h-64"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {popularFormations?.slice(0, 6).map((formation) => (
                <FormationCard key={formation.id} formation={formation} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/formations">
              <CyberButton variant="outline" size="lg">
                <span>Voir toutes les formations</span>
                <ArrowRight className="w-5 h-5 ml-2" />
              </CyberButton>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured News Section */}
      <section className="py-20 bg-cyber-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Actualités <span className="text-cyber-accent">Cybersécurité</span>
            </h2>
            <p className="text-xl text-cyber-text-secondary max-w-3xl mx-auto">
              Restez informé des dernières menaces et innovations en sécurité informatique.
            </p>
          </div>

          {loadingArticles ? (
            <div className="space-y-8">
              <div className="animate-pulse bg-cyber-dark rounded-xl h-64"></div>
              <div className="grid md:grid-cols-2 gap-8">
                {[1, 2].map((i) => (
                  <div key={i} className="animate-pulse bg-cyber-dark rounded-xl h-48"></div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              {featuredArticles?.[0] && (
                <NewsCard article={featuredArticles[0]} featured />
              )}
              
              <div className="grid md:grid-cols-2 gap-8">
                {featuredArticles?.slice(1, 3).map((article) => (
                  <NewsCard key={article.id} article={article} />
                ))}
              </div>
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/actualites">
              <CyberButton variant="outline" size="lg">
                <span>Voir toutes les actualités</span>
                <ArrowRight className="w-5 h-5 ml-2" />
              </CyberButton>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-cyber-dark">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">
              Pourquoi choisir notre <span className="text-cyber-accent">plateforme</span> ?
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="glass-effect border-border hover:border-cyber-accent/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-cyber-accent/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <GraduationCap className="w-8 h-8 text-cyber-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Formations Pratiques</h3>
                <p className="text-cyber-text-secondary leading-relaxed">
                  Apprentissage par la pratique avec des labs virtuels et des exercices concrets.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border hover:border-cyber-accent/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-cyber-accent/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="w-8 h-8 text-cyber-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Communauté Active</h3>
                <p className="text-cyber-text-secondary leading-relaxed">
                  Échangez avec des experts et des passionnés dans notre canal Telegram.
                </p>
              </CardContent>
            </Card>

            <Card className="glass-effect border-border hover:border-cyber-accent/50 transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-cyber-accent/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Zap className="w-8 h-8 text-cyber-accent" />
                </div>
                <h3 className="text-xl font-semibold mb-4">Contenu Actualisé</h3>
                <p className="text-cyber-text-secondary leading-relaxed">
                  Formations et actualités mises à jour selon les dernières menaces.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-cyber-accent to-cyber-blue">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="glass-effect rounded-3xl p-12 border border-white/10 bg-cyber-dark/20">
              <div className="inline-block p-4 bg-white/10 rounded-2xl mb-6">
                <svg className="w-12 h-12 text-cyber-dark" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                </svg>
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-cyber-dark">
                Rejoignez Notre Communauté Telegram
              </h2>
              
              <p className="text-xl text-cyber-dark/80 mb-8 leading-relaxed">
                Rejoignez notre <span className="font-semibold">communauté naissante</span> pour partager des ressources, 
                poser vos questions et échanger sur les dernières actualités cybersécurité.
              </p>

              <div className="grid md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyber-dark mb-2">🔐</div>
                  <h4 className="font-semibold text-cyber-dark">Conseils Pratiques</h4>
                  <p className="text-sm text-cyber-dark/70">Tips quotidiens et bonnes pratiques</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyber-dark mb-2">🛠️</div>
                  <h4 className="font-semibold text-cyber-dark">Outils Gratuits</h4>
                  <p className="text-sm text-cyber-dark/70">Scripts et utilitaires de sécurité</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyber-dark mb-2">📢</div>
                  <h4 className="font-semibold text-cyber-dark">Actualités</h4>
                  <p className="text-sm text-cyber-dark/70">Alertes et veille cybersécurité</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <CyberButton
                  variant="default"
                  size="lg"
                  glow
                  onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                  className="bg-cyber-dark text-white hover:bg-cyber-secondary flex items-center space-x-3"
                >
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                  </svg>
                  <span>Rejoindre Maintenant</span>
                </CyberButton>
                
                <CyberButton
                  variant="outline"
                  size="lg"
                  className="border-cyber-dark text-cyber-dark hover:bg-cyber-dark hover:text-white"
                  onClick={() => navigator.clipboard.writeText(TELEGRAM_CHANNEL_URL)}
                >
                  <span>Copier le Lien</span>
                </CyberButton>
              </div>

              <p className="mt-6 text-cyber-dark/70 font-mono text-sm">
                🔗 <strong>{TELEGRAM_CHANNEL_URL}</strong>
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
