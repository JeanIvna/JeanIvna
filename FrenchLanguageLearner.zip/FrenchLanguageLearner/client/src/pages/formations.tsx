import { useState } from "react";
import { FormationCard } from "@/components/formations/formation-card";
import { SearchFilter } from "@/components/formations/search-filter";
import { useFormations } from "@/hooks/use-formations";
import { Skeleton } from "@/components/ui/skeleton";

export default function Formations() {
  const [filters, setFilters] = useState<{ level?: string; category?: string; search?: string }>({});
  const { data: formations, isLoading, error } = useFormations(filters);

  if (error) {
    return (
      <div className="min-h-screen bg-cyber-dark flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Erreur de chargement</h2>
          <p className="text-cyber-text-secondary">Impossible de charger les formations.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cyber-dark">
      {/* Header */}
      <section className="py-20 bg-gradient-to-b from-cyber-dark to-cyber-secondary">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">
              Formations <span className="text-cyber-accent">Cybersécurité</span>
            </h1>
            <p className="text-xl text-cyber-text-secondary max-w-3xl mx-auto">
              Du débutant à l'expert, découvrez nos tutoriels pratiques et nos guides complets pour maîtriser la sécurité informatique.
            </p>
          </div>

          {/* Search and Filters */}
          <SearchFilter
            onFilterChange={setFilters}
            currentFilters={filters}
          />
        </div>
      </section>

      {/* Formations Grid */}
      <section className="py-12 bg-cyber-dark">
        <div className="container mx-auto px-6">
          {isLoading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="h-48 w-full bg-cyber-secondary" />
                  <Skeleton className="h-4 w-3/4 bg-cyber-secondary" />
                  <Skeleton className="h-4 w-1/2 bg-cyber-secondary" />
                  <Skeleton className="h-8 w-full bg-cyber-secondary" />
                </div>
              ))}
            </div>
          ) : formations && formations.length > 0 ? (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {formations.map((formation) => (
                  <FormationCard key={formation.id} formation={formation} />
                ))}
              </div>
              
              {formations.length > 9 && (
                <div className="text-center mt-12">
                  <p className="text-cyber-text-secondary mb-4">
                    Affichage de {formations.length} formation{formations.length > 1 ? 's' : ''}
                  </p>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-20">
              <div className="max-w-md mx-auto">
                <div className="w-24 h-24 bg-cyber-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                  <svg className="w-12 h-12 text-cyber-text-secondary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.5-1.003-6-2.709M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-cyber-text mb-2">Aucune formation trouvée</h3>
                <p className="text-cyber-text-secondary mb-6">
                  Aucune formation ne correspond à vos critères de recherche. Essayez de modifier vos filtres.
                </p>
                <button
                  onClick={() => setFilters({})}
                  className="text-cyber-accent hover:text-cyan-400 transition-colors duration-300"
                >
                  Effacer tous les filtres
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
