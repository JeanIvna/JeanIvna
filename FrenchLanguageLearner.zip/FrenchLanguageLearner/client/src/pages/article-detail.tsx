import { useParams, Link } from "wouter";
import { ArrowLeft, Clock, User, Eye, Share2, MessageCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CyberButton } from "@/components/ui/cyber-button";
import { useArticle } from "@/hooks/use-news";
import { ARTICLE_CATEGORIES, TELEGRAM_CHANNEL_URL } from "@/lib/constants";
import { Skeleton } from "@/components/ui/skeleton";

export default function ArticleDetail() {
  const { id } = useParams();
  const { data: article, isLoading, error } = useArticle(parseInt(id || "0"));

  if (isLoading) {
    return (
      <div className="min-h-screen bg-cyber-dark">
        <div className="container mx-auto px-6 py-12">
          <Skeleton className="h-8 w-32 mb-8 bg-cyber-secondary" />
          <div className="max-w-4xl mx-auto space-y-6">
            <Skeleton className="h-64 w-full bg-cyber-secondary" />
            <Skeleton className="h-8 w-3/4 bg-cyber-secondary" />
            <Skeleton className="h-32 w-full bg-cyber-secondary" />
            <Skeleton className="h-64 w-full bg-cyber-secondary" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-cyber-dark flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Article introuvable</h2>
          <p className="text-cyber-text-secondary mb-6">
            L'article que vous recherchez n'existe pas ou a été supprimé.
          </p>
          <Link href="/actualites">
            <CyberButton variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour aux actualités
            </CyberButton>
          </Link>
        </div>
      </div>
    );
  }

  const categoryInfo = ARTICLE_CATEGORIES[article.category as keyof typeof ARTICLE_CATEGORIES];
  
  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Il y a quelques minutes";
    if (diffInHours < 24) return `Il y a ${diffInHours}h`;
    if (diffInHours < 48) return "Il y a 1 jour";
    return `Il y a ${Math.floor(diffInHours / 24)} jours`;
  };

  const shareArticle = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      // You could show a toast notification here
    }
  };

  return (
    <div className="min-h-screen bg-cyber-dark">
      <div className="container mx-auto px-6 py-12">
        {/* Breadcrumb */}
        <Link href="/actualites">
          <div className="flex items-center text-cyber-accent hover:text-cyan-400 transition-colors duration-300 mb-8 cursor-pointer">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour aux actualités
          </div>
        </Link>

        <div className="max-w-4xl mx-auto">
          {/* Article Header */}
          <div className="mb-8">
            <div className="flex items-center gap-4 mb-4">
              <Badge className={categoryInfo?.color || "bg-cyber-accent/20 text-cyber-accent"}>
                {categoryInfo?.label || article.category}
              </Badge>
              <div className="flex items-center space-x-4 text-sm text-cyber-text-secondary">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{formatDate(article.createdAt!)}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <User className="w-4 h-4" />
                  <span>{article.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Eye className="w-4 h-4" />
                  <span>{article.views?.toLocaleString()} vues</span>
                </div>
              </div>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">
              {article.title}
            </h1>
            
            <p className="text-xl text-cyber-text-secondary leading-relaxed mb-6">
              {article.excerpt}
            </p>

            {/* Share Actions */}
            <div className="flex items-center space-x-4">
              <CyberButton
                variant="outline"
                size="sm"
                onClick={shareArticle}
                className="flex items-center space-x-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Partager</span>
              </CyberButton>

              <CyberButton
                variant="outline"
                size="sm"
                onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                className="flex items-center space-x-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Discuter sur Telegram</span>
              </CyberButton>
            </div>
          </div>

          {/* Article Image */}
          {article.imageUrl && (
            <div className="relative overflow-hidden rounded-xl mb-8">
              <img 
                src={article.imageUrl} 
                alt={article.title}
                className="w-full h-64 md:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cyber-dark/50 to-transparent"></div>
            </div>
          )}

          {/* Article Content */}
          <Card className="bg-cyber-secondary border-border mb-8">
            <CardContent className="p-8">
              <div className="prose prose-invert max-w-none">
                <div className="text-cyber-text-secondary leading-relaxed space-y-6">
                  {/* Split content into paragraphs for better readability */}
                  {article.content.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="text-lg leading-relaxed">
                      {paragraph.trim()}
                    </p>
                  ))}
                </div>

                {/* Security Alert Box (if article is critical) */}
                {article.category === 'critique' && (
                  <div className="mt-8 p-6 bg-red-500/10 border border-red-500/30 rounded-lg">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-red-500/20 rounded-full flex items-center justify-center mt-1">
                        <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16c-.77.833.192 2.5 1.732 2.5z" />
                        </svg>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-red-400 mb-2">⚠️ Alerte Sécurité Critique</h3>
                        <p className="text-cyber-text-secondary">
                          Cette vulnérabilité nécessite une action immédiate. Assurez-vous de mettre à jour vos systèmes et de suivre les recommandations de sécurité.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Recommendations Box */}
                <div className="mt-8 p-6 bg-cyber-accent/10 border border-cyber-accent/30 rounded-lg">
                  <h3 className="text-lg font-semibold text-cyber-accent mb-4">
                    💡 Recommandations
                  </h3>
                  <ul className="space-y-2 text-cyber-text-secondary">
                    <li>✅ Restez informé des dernières actualités de sécurité</li>
                    <li>✅ Appliquez les correctifs de sécurité dès qu'ils sont disponibles</li>
                    <li>✅ Rejoignez notre communauté Telegram pour des discussions approfondies</li>
                    <li>✅ Consultez nos formations pour approfondir vos connaissances</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Article Footer */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="flex items-center space-x-6 text-sm text-cyber-text-secondary">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Par {article.author}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>Publié {formatDate(article.createdAt!)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4" />
                <span>{article.views?.toLocaleString()} lectures</span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <CyberButton
                variant="outline"
                size="sm"
                onClick={shareArticle}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Partager l'article
              </CyberButton>
            </div>
          </div>

          {/* Join Community CTA */}
          <Card className="bg-gradient-to-br from-cyber-accent to-cyber-blue border-0 mt-12">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-white mb-4">Discutez de cet article</h3>
              <p className="text-white/90 mb-6 max-w-2xl mx-auto">
                Rejoignez notre communauté Telegram pour échanger avec des experts et approfondir vos connaissances sur ce sujet.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <CyberButton
                  variant="default"
                  size="lg"
                  className="bg-white text-cyber-dark hover:bg-gray-100"
                  onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                >
                  🚀 Rejoindre la discussion
                </CyberButton>
                <Link href="/formations">
                  <CyberButton
                    variant="outline"
                    size="lg"
                    className="border-white text-white hover:bg-white/10"
                  >
                    📚 Voir les formations
                  </CyberButton>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
