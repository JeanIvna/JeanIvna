import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FORMATION_LEVELS, FORMATION_CATEGORIES } from "@/lib/constants";

interface SearchFilterProps {
  onFilterChange: (filters: { level?: string; category?: string; search?: string }) => void;
  currentFilters: { level?: string; category?: string; search?: string };
}

export function SearchFilter({ onFilterChange, currentFilters }: SearchFilterProps) {
  const [searchQuery, setSearchQuery] = useState(currentFilters.search || "");

  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    onFilterChange({ ...currentFilters, search: value });
  };

  const handleLevelFilter = (level: string) => {
    const newLevel = currentFilters.level === level ? undefined : level;
    onFilterChange({ ...currentFilters, level: newLevel });
  };

  const handleCategoryFilter = (category: string) => {
    const newCategory = currentFilters.category === category ? undefined : category;
    onFilterChange({ ...currentFilters, category: newCategory });
  };

  const clearFilters = () => {
    setSearchQuery("");
    onFilterChange({});
  };

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative max-w-md mx-auto">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyber-text-secondary" />
        <Input
          type="text"
          placeholder="Rechercher une formation..."
          value={searchQuery}
          onChange={(e) => handleSearchChange(e.target.value)}
          className="pl-10 bg-cyber-dark border-border focus:border-cyber-accent"
        />
      </div>

      {/* Level Filters */}
      <div className="flex flex-wrap justify-center gap-3">
        <Button
          variant={!currentFilters.level && !currentFilters.category ? "default" : "outline"}
          onClick={clearFilters}
          className="bg-cyber-accent text-cyber-dark hover:bg-cyan-400"
        >
          Tous
        </Button>
        
        {Object.entries(FORMATION_LEVELS).map(([level, info]) => (
          <Button
            key={level}
            variant={currentFilters.level === level ? "default" : "outline"}
            onClick={() => handleLevelFilter(level)}
            className={
              currentFilters.level === level
                ? "bg-cyber-accent text-cyber-dark hover:bg-cyan-400"
                : "border-border text-cyber-text hover:bg-cyber-secondary"
            }
          >
            {info.label}
          </Button>
        ))}
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap justify-center gap-3">
        {Object.entries(FORMATION_CATEGORIES).map(([category, info]) => (
          <Button
            key={category}
            variant={currentFilters.category === category ? "default" : "outline"}
            onClick={() => handleCategoryFilter(category)}
            className={
              currentFilters.category === category
                ? "bg-cyber-blue text-white hover:bg-blue-600"
                : "border-border text-cyber-text hover:bg-cyber-secondary"
            }
          >
            {info.label}
          </Button>
        ))}
      </div>

      {/* Active Filters Display */}
      {(currentFilters.level || currentFilters.category || currentFilters.search) && (
        <div className="flex items-center justify-center gap-2 text-sm text-cyber-text-secondary">
          <span>Filtres actifs:</span>
          {currentFilters.level && (
            <span className="px-2 py-1 bg-cyber-accent/20 text-cyber-accent rounded">
              Niveau: {FORMATION_LEVELS[currentFilters.level as keyof typeof FORMATION_LEVELS]?.label}
            </span>
          )}
          {currentFilters.category && (
            <span className="px-2 py-1 bg-cyber-blue/20 text-cyber-blue rounded">
              Catégorie: {FORMATION_CATEGORIES[currentFilters.category as keyof typeof FORMATION_CATEGORIES]?.label}
            </span>
          )}
          {currentFilters.search && (
            <span className="px-2 py-1 bg-cyber-secondary border border-border rounded">
              Recherche: "{currentFilters.search}"
            </span>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="text-cyber-accent hover:text-cyan-400"
          >
            Effacer
          </Button>
        </div>
      )}
    </div>
  );
}
