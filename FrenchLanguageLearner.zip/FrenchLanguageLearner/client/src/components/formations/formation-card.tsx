import { Link } from "wouter";
import { Clock, Users, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CyberButton } from "@/components/ui/cyber-button";
import { FORMATION_LEVELS } from "@/lib/constants";
import type { Formation } from "@shared/schema";

interface FormationCardProps {
  formation: Formation;
}

export function FormationCard({ formation }: FormationCardProps) {
  const levelInfo = FORMATION_LEVELS[formation.level as keyof typeof FORMATION_LEVELS];

  return (
    <Card className="group bg-cyber-secondary border-border hover:border-cyber-accent/50 transition-all duration-300 transform hover:-translate-y-1">
      <div className="relative overflow-hidden rounded-t-lg">
        {formation.imageUrl && (
          <img 
            src={formation.imageUrl} 
            alt={formation.title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
          />
        )}
        
        {formation.isPopular && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-cyber-accent/90 text-cyber-dark">
              <Star className="w-3 h-3 mr-1" />
              Populaire
            </Badge>
          </div>
        )}
      </div>
      
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Badge className={levelInfo?.color || "bg-cyber-accent/20 text-cyber-accent"}>
            {levelInfo?.label || formation.level}
          </Badge>
          <div className="flex items-center space-x-2 text-sm text-cyber-text-secondary">
            <Clock className="w-4 h-4" />
            <span>{formation.duration}</span>
          </div>
        </div>
        
        <h3 className="text-xl font-semibold mb-3 group-hover:text-cyber-accent transition-colors duration-300">
          {formation.title}
        </h3>
        
        <p className="text-cyber-text-secondary mb-4 text-sm leading-relaxed">
          {formation.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm text-cyber-text-secondary">
            <div className="flex items-center space-x-1">
              <Users className="w-4 h-4" />
              <span>1.2k étudiants</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-400" />
              <span>4.8</span>
            </div>
          </div>
          
          <Link href={`/formations/${formation.id}`}>
            <CyberButton size="sm">
              Commencer
            </CyberButton>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
