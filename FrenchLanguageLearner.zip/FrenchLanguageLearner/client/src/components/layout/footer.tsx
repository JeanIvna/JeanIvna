import { Link } from "wouter";
import { Shield, Mail, Globe, Users } from "lucide-react";
import { TELEGRAM_CHANNEL_URL } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="bg-cyber-secondary border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand & Description */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-cyber-accent to-cyber-blue rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-cyber-text">Sécurité Informatique</h3>
                <p className="text-sm text-cyber-text-secondary">Formation et actualités cybersécurité</p>
              </div>
            </div>
            
            <p className="text-cyber-text-secondary mb-6 leading-relaxed max-w-md">
              Votre plateforme de référence pour apprendre la cybersécurité. Formations gratuites, 
              communauté active et ressources pratiques pour tous les niveaux.
            </p>

            <div className="flex space-x-4">
              <a 
                href={TELEGRAM_CHANNEL_URL} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-cyber-dark rounded-lg flex items-center justify-center hover:bg-cyber-accent hover:text-cyber-dark transition-colors duration-300"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-cyber-text">Navigation</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <span className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300 cursor-pointer">
                    Accueil
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/formations">
                  <span className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300 cursor-pointer">
                    Formations
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/actualites">
                  <span className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300 cursor-pointer">
                    Actualités
                  </span>
                </Link>
              </li>
              <li>
                <a 
                  href={TELEGRAM_CHANNEL_URL} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300"
                >
                  Canal Telegram
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 text-cyber-text">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center space-x-3 text-cyber-text-secondary">
                <Mail className="w-4 h-4 text-cyber-accent" />
                <span>Micheekama@gmail.com</span>
              </li>
              <li className="flex items-center space-x-3 text-cyber-text-secondary">
                <svg className="w-4 h-4 text-cyber-accent" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.374 0 0 5.373 0 12s5.374 12 12 12 12-5.373 12-12S18.626 0 12 0zm5.568 8.16l-1.61 7.56c-.12.54-.45.67-.91.42l-2.5-1.84-1.21 1.16c-.13.13-.24.24-.5.24l.18-2.49 4.64-4.19c.2-.18-.04-.28-.31-.1l-5.74 3.61-2.47-.77c-.54-.17-.55-.54.11-.8l9.66-3.72c.45-.17.84.11.7.8z"/>
                </svg>
                <span>@securiteinformatique123</span>
              </li>
              <li className="flex items-center space-x-3 text-cyber-text-secondary">
                <Globe className="w-4 h-4 text-cyber-accent" />
                <span>securite-informatique.fr</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-cyber-text-secondary text-sm mb-4 md:mb-0">
              &copy; 2025 Sécurité Informatique ¹²³ | Tous droits réservés.
            </p>
            
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300">
                Politique de Confidentialité
              </a>
              <a href="#" className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300">
                Conditions d'Utilisation
              </a>
              <a href="#" className="text-cyber-text-secondary hover:text-cyber-accent transition-colors duration-300">
                Mentions Légales
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
