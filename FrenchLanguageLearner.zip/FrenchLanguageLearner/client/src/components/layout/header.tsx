import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, Menu, X, Shield } from "lucide-react";
import { CyberButton } from "@/components/ui/cyber-button";
import { Input } from "@/components/ui/input";
import { TELEGRAM_CHANNEL_URL } from "@/lib/constants";
import { useGlobalSearch } from "@/hooks/use-news";

export function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { data: searchResults } = useGlobalSearch(searchQuery);

  const navigation = [
    { name: "Accueil", href: "/" },
    { name: "Formations", href: "/formations" },
    { name: "Actualités", href: "/actualites" },
    { name: "À propos", href: "#about" },
  ];

  const isActive = (href: string) => {
    if (href === "/") return location === "/";
    return location.startsWith(href);
  };

  return (
    <header className="sticky top-0 z-50 bg-cyber-secondary/95 backdrop-blur-md border-b border-border">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-10 h-10 bg-gradient-to-br from-cyber-accent to-cyber-blue rounded-lg flex items-center justify-center cyber-glow">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-cyber-accent">Sécurité Informatique</h1>
                <p className="text-xs text-cyber-text-secondary">Formation & Communauté</p>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navigation.map((item) => (
              <Link key={item.name} href={item.href}>
                <span
                  className={cn(
                    "text-cyber-text hover:text-cyber-accent transition-colors duration-300 font-medium cursor-pointer",
                    isActive(item.href) && "text-cyber-accent"
                  )}
                >
                  {item.name}
                </span>
              </Link>
            ))}
          </div>

          {/* Search and Actions */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-cyber-text-secondary" />
              <Input
                type="text"
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64 bg-cyber-dark border-border focus:border-cyber-accent"
              />
              
              {/* Search Results Dropdown */}
              {searchResults && searchQuery.length > 2 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-cyber-secondary border border-border rounded-lg shadow-lg max-h-96 overflow-y-auto z-50">
                  {searchResults.formations?.length > 0 && (
                    <div className="p-3">
                      <h4 className="text-sm font-semibold text-cyber-accent mb-2">Formations</h4>
                      {searchResults.formations.map((formation: any) => (
                        <Link key={formation.id} href={`/formations/${formation.id}`}>
                          <div className="p-2 hover:bg-cyber-dark rounded cursor-pointer">
                            <p className="text-sm text-cyber-text">{formation.title}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                  
                  {searchResults.articles?.length > 0 && (
                    <div className="p-3">
                      <h4 className="text-sm font-semibold text-cyber-accent mb-2">Actualités</h4>
                      {searchResults.articles.map((article: any) => (
                        <Link key={article.id} href={`/actualites/${article.id}`}>
                          <div className="p-2 hover:bg-cyber-dark rounded cursor-pointer">
                            <p className="text-sm text-cyber-text">{article.title}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                  
                  {(!searchResults.formations?.length && !searchResults.articles?.length) && (
                    <div className="p-4 text-center text-cyber-text-secondary">
                      Aucun résultat trouvé
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden text-cyber-text hover:text-cyber-accent"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-border pt-4">
            <div className="flex flex-col space-y-3">
              {navigation.map((item) => (
                <Link key={item.name} href={item.href}>
                  <span
                    className={cn(
                      "text-cyber-text hover:text-cyber-accent transition-colors duration-300 cursor-pointer",
                      isActive(item.href) && "text-cyber-accent"
                    )}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.name}
                  </span>
                </Link>
              ))}
              
              {/* Mobile Search */}
              <div className="mt-4">
                <Input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-cyber-dark border-border focus:border-cyber-accent"
                />
              </div>
              
              {/* Mobile Telegram Button */}
              <div className="mt-4">
                <CyberButton
                  variant="telegram"
                  size="md"
                  glow
                  onClick={() => window.open(TELEGRAM_CHANNEL_URL, '_blank')}
                  className="w-full"
                >
                  🚀 Rejoindre Telegram
                </CyberButton>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}

function cn(...classes: (string | boolean | undefined)[]): string {
  return classes.filter(Boolean).join(' ');
}
