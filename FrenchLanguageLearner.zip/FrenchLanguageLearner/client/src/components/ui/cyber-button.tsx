import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface CyberButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline" | "ghost" | "telegram";
  size?: "sm" | "md" | "lg";
  glow?: boolean;
}

const CyberButton = forwardRef<HTMLButtonElement, CyberButtonProps>(
  ({ className, variant = "default", size = "md", glow = false, ...props }, ref) => {
    return (
      <button
        className={cn(
          "inline-flex items-center justify-center rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-cyber-accent/25 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none",
          {
            // Variants
            "bg-cyber-accent hover:bg-cyan-400 text-cyber-dark": variant === "default",
            "border-2 border-cyber-accent text-cyber-accent hover:bg-cyber-accent hover:text-cyber-dark": variant === "outline",
            "text-cyber-text hover:text-cyber-accent hover:bg-cyber-secondary": variant === "ghost",
            "bg-gradient-to-r from-cyber-accent to-cyber-blue hover:from-cyber-blue hover:to-cyan-400 text-white": variant === "telegram",
            
            // Sizes
            "px-4 py-2 text-sm": size === "sm",
            "px-6 py-3 text-base": size === "md",
            "px-8 py-4 text-lg": size === "lg",
            
            // Glow effect
            "cyber-glow": glow,
          },
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);

CyberButton.displayName = "CyberButton";

export { CyberButton };
