import { Link } from "wouter";
import { Eye, User, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ARTICLE_CATEGORIES } from "@/lib/constants";
import type { Article } from "@shared/schema";

interface NewsCardProps {
  article: Article;
  featured?: boolean;
}

export function NewsCard({ article, featured = false }: NewsCardProps) {
  const categoryInfo = ARTICLE_CATEGORIES[article.category as keyof typeof ARTICLE_CATEGORIES];
  
  const formatDate = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Il y a quelques minutes";
    if (diffInHours < 24) return `Il y a ${diffInHours}h`;
    if (diffInHours < 48) return "Il y a 1 jour";
    return `Il y a ${Math.floor(diffInHours / 24)} jours`;
  };

  if (featured) {
    return (
      <Card className="group bg-cyber-dark border-border hover:border-cyber-accent/50 transition-all duration-300 overflow-hidden">
        <div className="lg:flex">
          {article.imageUrl && (
            <div className="lg:w-1/2">
              <img 
                src={article.imageUrl} 
                alt={article.title}
                className="w-full h-64 lg:h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
          )}
          
          <CardContent className="p-8 lg:w-1/2">
            <div className="flex items-center gap-4 mb-4">
              <Badge className={categoryInfo?.color || "bg-cyber-accent/20 text-cyber-accent"}>
                {categoryInfo?.label || article.category}
              </Badge>
              <div className="flex items-center space-x-2 text-sm text-cyber-text-secondary">
                <Clock className="w-4 h-4" />
                <span>{formatDate(article.createdAt!)}</span>
              </div>
            </div>
            
            <h2 className="text-2xl font-bold mb-4 group-hover:text-cyber-accent transition-colors duration-300">
              {article.title}
            </h2>
            
            <p className="text-cyber-text-secondary mb-6 leading-relaxed">
              {article.excerpt}
            </p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-sm text-cyber-text-secondary">
                <div className="flex items-center space-x-1">
                  <User className="w-4 h-4" />
                  <span>{article.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Eye className="w-4 h-4" />
                  <span>{article.views?.toLocaleString()} vues</span>
                </div>
              </div>
              
              <Link href={`/actualites/${article.id}`}>
                <span className="inline-flex items-center text-cyber-accent hover:text-cyan-400 transition-colors duration-300 cursor-pointer">
                  Lire l'article complet
                  <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </span>
              </Link>
            </div>
          </CardContent>
        </div>
      </Card>
    );
  }

  return (
    <Card className="group bg-cyber-dark border-border hover:border-cyber-accent/50 transition-all duration-300 overflow-hidden">
      {article.imageUrl && (
        <div className="relative overflow-hidden">
          <img 
            src={article.imageUrl} 
            alt={article.title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      )}
      
      <CardContent className="p-6">
        <div className="flex items-center gap-3 mb-3">
          <Badge className={categoryInfo?.color || "bg-cyber-accent/20 text-cyber-accent"} size="sm">
            {categoryInfo?.label || article.category}
          </Badge>
          <div className="flex items-center space-x-1 text-xs text-cyber-text-secondary">
            <Clock className="w-3 h-3" />
            <span>{formatDate(article.createdAt!)}</span>
          </div>
        </div>
        
        <h3 className="text-lg font-semibold mb-3 group-hover:text-cyber-accent transition-colors duration-300">
          {article.title}
        </h3>
        
        <p className="text-cyber-text-secondary text-sm mb-4 leading-relaxed">
          {article.excerpt}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 text-xs text-cyber-text-secondary">
            <div className="flex items-center space-x-1">
              <User className="w-3 h-3" />
              <span>{article.author}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Eye className="w-3 h-3" />
              <span>{article.views?.toLocaleString()}</span>
            </div>
          </div>
          
          <Link href={`/actualites/${article.id}`}>
            <span className="text-cyber-accent hover:text-cyan-400 text-sm transition-colors duration-300 cursor-pointer">
              Lire plus →
            </span>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
