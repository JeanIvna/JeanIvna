import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Formation, InsertFormation } from "@shared/schema";

interface FormationFilters {
  level?: string;
  category?: string;
  search?: string;
}

export function useFormations(filters?: FormationFilters) {
  const queryParams = new URLSearchParams();
  if (filters?.level) queryParams.append('level', filters.level);
  if (filters?.category) queryParams.append('category', filters.category);
  if (filters?.search) queryParams.append('search', filters.search);

  return useQuery<Formation[]>({
    queryKey: ['/api/formations', filters],
    queryFn: async () => {
      const response = await fetch(`/api/formations?${queryParams}`);
      if (!response.ok) {
        throw new Error('Failed to fetch formations');
      }
      return response.json();
    },
  });
}

export function usePopularFormations() {
  return useQuery<Formation[]>({
    queryKey: ['/api/formations/popular'],
  });
}

export function useFormation(id: number) {
  return useQuery<Formation>({
    queryKey: ['/api/formations', id],
    enabled: !!id,
  });
}

export function useCreateFormation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: InsertFormation) => {
      const response = await apiRequest('POST', '/api/formations', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/formations'] });
    },
  });
}
