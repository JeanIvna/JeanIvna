import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Article, InsertArticle } from "@shared/schema";

interface ArticleFilters {
  category?: string;
  search?: string;
}

export function useArticles(filters?: ArticleFilters) {
  const queryParams = new URLSearchParams();
  if (filters?.category) queryParams.append('category', filters.category);
  if (filters?.search) queryParams.append('search', filters.search);

  return useQuery<Article[]>({
    queryKey: ['/api/articles', filters],
    queryFn: async () => {
      const response = await fetch(`/api/articles?${queryParams}`);
      if (!response.ok) {
        throw new Error('Failed to fetch articles');
      }
      return response.json();
    },
  });
}

export function useFeaturedArticles() {
  return useQuery<Article[]>({
    queryKey: ['/api/articles/featured'],
  });
}

export function useArticle(id: number) {
  return useQuery<Article>({
    queryKey: ['/api/articles', id],
    enabled: !!id,
  });
}

export function useCreateArticle() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: InsertArticle) => {
      const response = await apiRequest('POST', '/api/articles', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/articles'] });
    },
  });
}

export function useGlobalSearch(query: string) {
  return useQuery({
    queryKey: ['/api/search', query],
    queryFn: async () => {
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      if (!response.ok) {
        throw new Error('Search failed');
      }
      return response.json();
    },
    enabled: query.length > 2,
  });
}
