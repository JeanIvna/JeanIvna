export const TELEGRAM_CHANNEL_URL = "https://t.me/securiteinformatique123";

export const FORMATION_LEVELS = {
  debutant: { label: "Débutant", color: "bg-green-500/20 text-green-400" },
  intermediaire: { label: "Intermédiaire", color: "bg-blue-500/20 text-blue-400" },
  avance: { label: "Avancé", color: "bg-red-500/20 text-red-400" },
} as const;

export const FORMATION_CATEGORIES = {
  general: { label: "Général", icon: "shield-check" },
  pentest: { label: "Pentesting", icon: "sword" },
  forensics: { label: "Forensics", icon: "search" },
  network: { label: "Réseau", icon: "network" },
  web: { label: "Web Security", icon: "globe" },
  crypto: { label: "Cryptographie", icon: "key" },
  social: { label: "Social Engineering", icon: "users" },
} as const;

export const ARTICLE_CATEGORIES = {
  critique: { label: "Critique", color: "bg-red-500/20 text-red-400", icon: "alert-triangle" },
  alerte: { label: "Alerte", color: "bg-orange-500/20 text-orange-400", icon: "alert-circle" },
  info: { label: "Info", color: "bg-blue-500/20 text-blue-400", icon: "info" },
  innovation: { label: "Innovation", color: "bg-green-500/20 text-green-400", icon: "lightbulb" },
  reglementation: { label: "Réglementation", color: "bg-purple-500/20 text-purple-400", icon: "book" },
} as const;

export const TOOL_CATEGORIES = {
  gratuit: { label: "Gratuit", color: "bg-green-500/20 text-green-400" },
  freemium: { label: "Freemium", color: "bg-blue-500/20 text-blue-400" },
  pro: { label: "Pro", color: "bg-orange-500/20 text-orange-400" },
} as const;

export const SITE_STATS = {
  members: "Nouvelle communauté",
  tutorials: "10+",
  tools: "25+",
  discussions: "En développement",
};
