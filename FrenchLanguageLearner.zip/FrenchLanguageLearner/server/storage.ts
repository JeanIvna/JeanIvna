import { users, formations, articles, tools, type User, type InsertUser, type Formation, type InsertFormation, type Article, type InsertArticle, type Tool, type InsertTool } from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Formations
  getFormations(filters?: { level?: string; category?: string; search?: string }): Promise<Formation[]>;
  getFormation(id: number): Promise<Formation | undefined>;
  createFormation(formation: InsertFormation): Promise<Formation>;
  getPopularFormations(): Promise<Formation[]>;

  // Articles
  getArticles(filters?: { category?: string; search?: string }): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  incrementArticleViews(id: number): Promise<void>;
  getFeaturedArticles(): Promise<Article[]>;

  // Tools
  getTools(category?: string): Promise<Tool[]>;
  getTool(id: number): Promise<Tool | undefined>;
  createTool(tool: InsertTool): Promise<Tool>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private formations: Map<number, Formation>;
  private articles: Map<number, Article>;
  private tools: Map<number, Tool>;
  private currentUserId: number;
  private currentFormationId: number;
  private currentArticleId: number;
  private currentToolId: number;

  constructor() {
    this.users = new Map();
    this.formations = new Map();
    this.articles = new Map();
    this.tools = new Map();
    this.currentUserId = 1;
    this.currentFormationId = 1;
    this.currentArticleId = 1;
    this.currentToolId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample formations
    const sampleFormations: Omit<Formation, 'id'>[] = [
      {
        title: "Introduction à la Cybersécurité",
        description: "Les fondamentaux de la sécurité informatique, types d'attaques et méthodes de protection de base.",
        content: "Ce cours couvre les concepts essentiels de la cybersécurité. Vous apprendrez les bases de la protection des systèmes, la reconnaissance des menaces courantes, et les premières étapes pour sécuriser vos équipements personnels et professionnels.\n\nContenu du cours :\n\n1. **Concepts de base**\n   - Qu'est-ce que la cybersécurité ?\n   - Types de menaces (malwares, phishing, ransomware)\n   - Principes de la sécurité informatique\n\n2. **Protection personnelle**\n   - Mots de passe sécurisés\n   - Authentification à deux facteurs\n   - Navigation sécurisée\n\n3. **Outils de base**\n   - Antivirus et anti-malware\n   - Firewalls personnels\n   - VPN et leur utilisation\n\n4. **Bonnes pratiques**\n   - Sauvegardes régulières\n   - Mises à jour système\n   - Sensibilisation aux arnaques\n\nCe cours est idéal pour les débutants qui souhaitent comprendre les enjeux de la cybersécurité et protéger efficacement leurs données personnelles.",
        level: "debutant",
        category: "general",
        duration: "2h 30min",
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: true,
        createdAt: new Date(),
      },
      {
        title: "Premiers Pas en Sécurité Web",
        description: "Découvrez les bases de la sécurité des applications web et les vulnérabilités les plus courantes.",
        content: "Cette formation vous initie aux fondamentaux de la sécurité web. Parfait pour débuter dans ce domaine passionnant.\n\nAu programme :\n\n1. **Introduction à la sécurité web**\n   - Architecture des applications web\n   - Protocoles HTTP/HTTPS\n   - Bases de la sécurité côté client et serveur\n\n2. **Vulnérabilités courantes**\n   - Injection SQL (bases)\n   - Cross-Site Scripting (XSS)\n   - Authentification faible\n   - Configuration incorrecte\n\n3. **Outils de diagnostic**\n   - Navigateur et outils de développement\n   - Extensions de sécurité\n   - Scanners de vulnérabilités gratuits\n\n4. **Protection et bonnes pratiques**\n   - Validation des données\n   - Chiffrement des communications\n   - Gestion des sessions\n   - Mise à jour des composants\n\nCette formation est conçue pour les débutants curieux de comprendre comment sécuriser les sites web et applications.",
        level: "debutant",
        category: "web",
        duration: "3h 00min",
        imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: true,
        createdAt: new Date(),
      },
      {
        title: "Analyse Forensique Digital",
        description: "Maîtrisez les outils et techniques d'investigation numérique. Récupération de données, analyse de logs et preuves digitales.",
        content: "Guide complet sur l'analyse forensique...",
        level: "intermediaire",
        category: "forensics",
        duration: "3h 45min",
        imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: false,
        createdAt: new Date(),
      },
      {
        title: "Sécurité Réseau & Firewall",
        description: "Sécurisez vos infrastructures réseau. Configuration de firewalls, détection d'intrusions et surveillance du trafic.",
        content: "Formation sur la sécurisation des réseaux...",
        level: "intermediaire",
        category: "network",
        duration: "4h 00min",
        imageUrl: "https://images.unsplash.com/photo-1563206767-5b18f218e8de?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: false,
        createdAt: new Date(),
      },
      {
        title: "Cryptographie Moderne",
        description: "Découvrez les algorithmes de chiffrement modernes. AES, RSA, signatures numériques et blockchain security.",
        content: "Cours complet sur la cryptographie moderne...",
        level: "avance",
        category: "crypto",
        duration: "3h 20min",
        imageUrl: "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: false,
        createdAt: new Date(),
      },
      {
        title: "Protégez-vous des Arnaques en Ligne",
        description: "Apprenez à reconnaître et éviter les tentatives de phishing, arnaques par email et manipulations sociales.",
        content: "Formation essentielle pour se protéger des attaques par ingénierie sociale. Idéale pour tous les utilisateurs d'internet.\n\n**Programme de la formation :**\n\n1. **Reconnaître les arnaques courantes**\n   - Phishing par email\n   - Faux sites web\n   - Arnaques sur les réseaux sociaux\n   - Messages SMS frauduleux\n\n2. **Techniques de manipulation**\n   - Urgence artificielle\n   - Autorité usurpée\n   - Chantage émotionnel\n   - Offres trop belles pour être vraies\n\n3. **Signaux d'alarme à repérer**\n   - Fautes d'orthographe\n   - URLs suspectes\n   - Demandes d'informations personnelles\n   - Pression temporelle\n\n4. **Conseils de protection**\n   - Vérification des sources\n   - Navigation sécurisée\n   - Gestion des informations personnelles\n   - Que faire en cas de doute\n\n**Astuces pratiques incluses :**\n- Comment vérifier un lien suspect\n- Signaler une tentative d'arnaque\n- Protéger ses proches\n- Récupérer après une arnaque",
        level: "debutant",
        category: "social",
        duration: "2h 15min",
        imageUrl: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: true,
        createdAt: new Date(),
      },
      {
        title: "Premiers Pas avec les Mots de Passe",
        description: "Guide complet pour créer et gérer des mots de passe sécurisés. Gestionnaires de mots de passe et authentification à deux facteurs.",
        content: "Formation pratique sur la gestion des mots de passe, pilier fondamental de la sécurité numérique.\n\n**Contenu détaillé :**\n\n1. **Pourquoi les mots de passe sont importants**\n   - Statistiques des piratages\n   - Conséquences d'un mot de passe faible\n   - Mythes et réalités\n\n2. **Créer un bon mot de passe**\n   - Règles de base (longueur, complexité)\n   - Techniques de mémorisation\n   - Erreurs à éviter absolument\n   - Générateurs de mots de passe\n\n3. **Gestionnaires de mots de passe**\n   - Pourquoi les utiliser\n   - Solutions gratuites recommandées\n   - Installation et configuration\n   - Synchronisation entre appareils\n\n4. **Authentification à deux facteurs (2FA)**\n   - Principe et avantages\n   - Applications d'authentification\n   - Codes de récupération\n   - Activation sur les sites principaux\n\n**Bonus pratique :**\n- Audit de vos mots de passe actuels\n- Migration vers un gestionnaire\n- Configuration 2FA étape par étape\n- Checklist de sécurité",
        level: "debutant",
        category: "general",
        duration: "1h 45min",
        imageUrl: "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        videoUrl: null,
        downloadUrl: null,
        isPopular: false,
        createdAt: new Date(),
      },
    ];

    // Sample articles
    const sampleArticles: Omit<Article, 'id'>[] = [
      {
        title: "10 Conseils Essentiels pour Débuter en Cybersécurité",
        excerpt: "Guide pratique pour les débutants qui souhaitent se lancer dans l'apprentissage de la cybersécurité. Ressources, outils et premières étapes.",
        content: "Débuter en cybersécurité peut sembler intimidant, mais avec les bonnes bases, tout devient plus accessible. Voici nos conseils pour bien commencer.\n\n**1. Commencez par les fondamentaux**\nAvant de vous lancer dans des techniques avancées, maîtrisez les bases : qu'est-ce qu'un firewall, comment fonctionnent les mots de passe, pourquoi les mises à jour sont importantes.\n\n**2. Protégez d'abord vos propres équipements**\nLa meilleure façon d'apprendre est de commencer par sécuriser vos propres appareils. Installez un antivirus, activez l'authentification à deux facteurs, utilisez un gestionnaire de mots de passe.\n\n**3. Suivez l'actualité sécurité**\nRestez informé des dernières menaces et vulnérabilités. Suivez des blogs spécialisés, rejoignez des communautés comme notre canal Telegram.\n\n**4. Pratiquez dans un environnement sûr**\nUtilisez des machines virtuelles et des labs en ligne pour tester vos connaissances sans risque.\n\n**5. Apprenez les outils de base**\nFamiliarisez-vous avec des outils gratuits comme Nmap, Wireshark, ou les extensions de navigateur pour la sécurité.\n\n**6. Développez votre esprit critique**\nLa cybersécurité, c'est aussi savoir identifier les tentatives d'arnaque et les comportements suspects.\n\n**7. Rejoignez une communauté**\nÉchangez avec d'autres passionnés, posez vos questions, partagez vos découvertes.\n\n**8. Commencez petit et progressez**\nNe cherchez pas à tout apprendre d'un coup. Fixez-vous des objectifs atteignables.\n\n**9. Documentez vos apprentissages**\nTenez un carnet de vos découvertes, cela vous aidera à mémoriser et progresser.\n\n**10. Soyez patient et persévérant**\nLa cybersécurité est un domaine vaste qui demande du temps pour être maîtrisé. Chaque petit progrès compte !",
        author: "Michel Ekama",
        category: "info",
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        views: 524,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        title: "Comment Choisir un Bon Antivirus Gratuit en 2025",
        excerpt: "Comparatif des meilleures solutions antivirus gratuites disponibles. Conseils pour protéger efficacement votre ordinateur sans dépenser.",
        content: "Choisir un bon antivirus gratuit n'est pas toujours évident. Voici notre guide pour vous aider à faire le bon choix.\n\n**Les critères importants :**\n\n1. **Taux de détection**\nUn bon antivirus doit détecter au moins 95% des menaces connues. Consultez les tests indépendants d'AV-Test ou AV-Comparatives.\n\n2. **Impact sur les performances**\nVotre antivirus ne doit pas ralentir votre ordinateur. Privilégiez les solutions légères.\n\n3. **Facilité d'utilisation**\nL'interface doit être simple et intuitive, surtout si vous débutez.\n\n4. **Mises à jour régulières**\nLes définitions de virus doivent être mises à jour quotidiennement.\n\n**Nos recommandations 2025 :**\n\n**Avast Free Antivirus**\n- ✅ Excellent taux de détection\n- ✅ Interface intuitive\n- ⚠️ Publicités pour la version payante\n\n**AVG AntiVirus Free**\n- ✅ Léger et efficace\n- ✅ Scan en temps réel\n- ⚠️ Fonctionnalités limitées\n\n**Windows Defender** (intégré à Windows)\n- ✅ Déjà installé\n- ✅ Aucune publicité\n- ✅ Régulièrement mis à jour\n- ⚠️ Protection basique\n\n**Conseils d'installation :**\n- Désinstallez votre ancien antivirus avant\n- Redémarrez après installation\n- Effectuez un scan complet initial\n- Configurez les mises à jour automatiques\n\n**Important :** Un antivirus seul ne suffit pas ! Complétez avec des bonnes pratiques : mots de passe forts, mises à jour système, prudence avec les emails.",
        author: "Michel Ekama",
        category: "info",
        imageUrl: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        views: 342,
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      },
      {
        title: "L'IA révolutionne la détection des malwares",
        excerpt: "Les nouvelles technologies d'intelligence artificielle permettent désormais de détecter 99.8% des malwares inconnus.",
        content: "L'intelligence artificielle transforme radicalement la cybersécurité...",
        author: "AI Security Lab",
        category: "innovation",
        imageUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        views: 2156,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
    ];

    // Sample tools
    const sampleTools: Omit<Tool, 'id'>[] = [
      {
        name: "Nmap",
        description: "Scanner de réseau et audit de sécurité",
        category: "gratuit",
        url: "https://nmap.org",
        iconName: "shield-check",
      },
      {
        name: "Burp Suite",
        description: "Test de sécurité d'applications web",
        category: "freemium",
        url: "https://portswigger.net/burp",
        iconName: "lock",
      },
      {
        name: "Wireshark",
        description: "Analyseur de protocole réseau",
        category: "gratuit",
        url: "https://wireshark.org",
        iconName: "settings",
      },
      {
        name: "Metasploit",
        description: "Framework de test d'intrusion",
        category: "pro",
        url: "https://metasploit.com",
        iconName: "book-open",
      },
    ];

    // Add sample data
    sampleFormations.forEach(formation => {
      const id = this.currentFormationId++;
      this.formations.set(id, { ...formation, id });
    });

    sampleArticles.forEach(article => {
      const id = this.currentArticleId++;
      this.articles.set(id, { ...article, id });
    });

    sampleTools.forEach(tool => {
      const id = this.currentToolId++;
      this.tools.set(id, { ...tool, id });
    });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Formations
  async getFormations(filters?: { level?: string; category?: string; search?: string }): Promise<Formation[]> {
    let formations = Array.from(this.formations.values());

    if (filters?.level) {
      formations = formations.filter(f => f.level === filters.level);
    }

    if (filters?.category) {
      formations = formations.filter(f => f.category === filters.category);
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      formations = formations.filter(f => 
        f.title.toLowerCase().includes(searchLower) ||
        f.description.toLowerCase().includes(searchLower)
      );
    }

    return formations.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getFormation(id: number): Promise<Formation | undefined> {
    return this.formations.get(id);
  }

  async createFormation(formation: InsertFormation): Promise<Formation> {
    const id = this.currentFormationId++;
    const newFormation: Formation = { 
      ...formation, 
      id,
      createdAt: new Date()
    };
    this.formations.set(id, newFormation);
    return newFormation;
  }

  async getPopularFormations(): Promise<Formation[]> {
    return Array.from(this.formations.values())
      .filter(f => f.isPopular)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  // Articles
  async getArticles(filters?: { category?: string; search?: string }): Promise<Article[]> {
    let articles = Array.from(this.articles.values());

    if (filters?.category) {
      articles = articles.filter(a => a.category === filters.category);
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      articles = articles.filter(a => 
        a.title.toLowerCase().includes(searchLower) ||
        a.excerpt.toLowerCase().includes(searchLower)
      );
    }

    return articles.sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async createArticle(article: InsertArticle): Promise<Article> {
    const id = this.currentArticleId++;
    const newArticle: Article = { 
      ...article, 
      id,
      views: 0,
      createdAt: new Date()
    };
    this.articles.set(id, newArticle);
    return newArticle;
  }

  async incrementArticleViews(id: number): Promise<void> {
    const article = this.articles.get(id);
    if (article) {
      article.views = (article.views || 0) + 1;
      this.articles.set(id, article);
    }
  }

  async getFeaturedArticles(): Promise<Article[]> {
    return Array.from(this.articles.values())
      .sort((a, b) => (b.views || 0) - (a.views || 0))
      .slice(0, 3);
  }

  // Tools
  async getTools(category?: string): Promise<Tool[]> {
    let tools = Array.from(this.tools.values());

    if (category) {
      tools = tools.filter(t => t.category === category);
    }

    return tools;
  }

  async getTool(id: number): Promise<Tool | undefined> {
    return this.tools.get(id);
  }

  async createTool(tool: InsertTool): Promise<Tool> {
    const id = this.currentToolId++;
    const newTool: Tool = { ...tool, id };
    this.tools.set(id, newTool);
    return newTool;
  }
}

export const storage = new MemStorage();
